import kotlin.math.pow

abstract class Imt : Student(){
    var imt: Double = weight / height.pow(2)
    override fun info(){
        println("Индекс массы тела: $imt")
    }
}