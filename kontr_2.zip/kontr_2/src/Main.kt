fun main(){
    print("Имя: ")
    val name = readLine()!!.toString()
    print("Фамилия: ")
    val surname = readLine()!!.toString()
    print("Отчество: ")
    val otc = readLine()!!.toString()
    print("Пол: ")
    val gender = readLine()!!.toString()
    print("Группа: ")
    val group = readLine()!!.toString()
    print("Дата рождения: ")
    val bd = readLine()!!.toString()
    print("Рост: ")
    val height = readLine()!!.toDouble()
    print("Вес: ")
    val weight = readLine()!!.toDouble()
    print("Вид спорта: ")
    val sport = readLine()!!.toString()

    var student1 = StudentMain(name, surname, otc, gender, group, bd, height, weight, sport)
    var st = "да"
    while (st == "да"){
        print("хотите узнать ваш индекс массы тела?: ")
        var answer = readLine()
        if (answer == "да"){
            Student.info(name, surname, otc, gender, group, bd, height, weight, sport)
            Imt.info()
        }
        else if (answer == "нет"){
            Student.info(name, surname, otc, gender, group, bd, height, weight, sport)
        }
        else{
            return
        }
        print("продолжить программу? (да/нет): ")
        st = readLine().toString()
    }
}