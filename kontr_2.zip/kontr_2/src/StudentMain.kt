class StudentMain {
    open fun info(name: String,surname: String,otc: String,gender: String, group: String, bd: String, height: Double, weight: Double, sport: String){
        println("Имя: $name")
        println("Фамилия: $surname")
        println("Отчество: $otc")
        println("Пол: $gender")
        println("Группа: $group")
        println("Дата рождения: $bd")
        println("Рост: $height")
        println("Вес: $weight")
        println("Вид спорта: $sport")
    }
}