abstract class Student{
    abstract val name: String
    abstract val surname: String
    abstract val otc: String
    abstract val gender: String
    abstract val group: String
    abstract val bd: String
    abstract val height: Double
    abstract val weight: Double
    abstract val sport: String

    open fun info(){
        println("Имя: $name")
        println("Фамилия: $surname")
        println("Отчество: $otc")
        println("Пол: $gender")
        println("Группа: $group")
        println("Дата рождения: $bd")
        println("Рост: $height")
        println("Вес: $weight")
        println("Вид спорта: $sport")

    }
}